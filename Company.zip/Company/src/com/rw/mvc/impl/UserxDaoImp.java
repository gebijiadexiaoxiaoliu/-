package com.rw.mvc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.rw.mvc.dao.UserxDao;
import com.rw.mvc.entity.DBHelper;
import com.rw.mvc.entity.Userx;

public class UserxDaoImp implements UserxDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Userx userx = null;

	@Override
	public Userx login(String name, String password) {
		String sql = "select * from userx where name=? and password=?";
		
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			if(rs.next()){
				userx = new Userx();
				userx.setId(rs.getInt(1));
				userx.setName(rs.getString(2));
				userx.setPassword(rs.getString(3));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		return userx;
	}

}
