package com.rw.mvc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.rw.mvc.dao.CompanyDao;
import com.rw.mvc.entity.DBHelper;
import com.rw.mvc.entity.FenYe;
import com.rw.mvc.entity.News;
import com.rw.mvc.entity.Product;
import com.rw.mvc.entity.Users;

public class CompanyImpl implements CompanyDao {

		// ��½
		@Override
		public Users login(String name, String password) {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			Users use=null;
			String sql="select * from users where name=? and password=?";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setString(1, name);
				pre.setString(2, password);
				re=pre.executeQuery();
				if(re.next()){
					use = new Users();
					use.setId(re.getInt(1));
					use.setName(re.getString(2));
					use.setPassword(re.getString(3));
					use.setAdmin(re.getInt(4));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(re, pre, conn);
			}
			return use;
		}

		// ������ŵ�������
		@Override
		public int getCount() {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			int count = 0;
			String sql = "select count(*) from news";
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				re = pre.executeQuery();
				if (re.next()) {
					count = re.getInt(1);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(re, pre, conn);
			}

			return count;
		}

		// ��÷�ҳ�������
		@Override
		public List<News> tabAll(FenYe fy) {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			String sql = "select * from(select n.*, Rownum rn from(select * from news)n where rownum<=?) where rn >=?";
			List<News> list = new ArrayList<News>();
			News news = null;
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setInt(1, fy.getEndIndex());
				pre.setInt(2, fy.getStartIndex());
				re = pre.executeQuery();
				while (re.next()) {
					news = new News();
					news.setId(re.getInt(1));
					news.setNewtitle(re.getString(2));
					news.setNewconter(re.getString(3));
					news.setNewtime(re.getString(4));
					list.add(news);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(re, pre, conn);

			}
			return list;
		}

		// ͨ��id��ʾһ������
		public News getAnews(int id) {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			String sql = "select * from news where id=?";
			News news = null;
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setInt(1, id);
				re = pre.executeQuery();
				if (re.next()) {
					news = new News();
					news.setId(re.getInt(1));
					news.setNewtitle(re.getString(2));
					news.setNewconter(re.getString(3));
					news.setNewtime(re.getString(4));
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(re, pre, conn);
			}
			return news;
		}

		// �����Ʒ��ҳ
		@Override
		public List<Product> tabPro(FenYe fy) {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet res = null;
			List<Product> list = new ArrayList<Product>();
			String sql = "select * from(select p.*, Rownum rn from(select * from product)p where rownum<=?) where rn >=?";
			Product pro = null;
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setInt(1, fy.getEndIndex());
				pre.setInt(2, fy.getStartIndex());
				res = pre.executeQuery();
				while (res.next()) {
					pro = new Product();
					pro.setId(res.getInt(1));
					pro.setProid(res.getString(2));
					pro.setName(res.getString(3));
					pro.setShangbiao(res.getString(4));
					pro.setTypees(res.getString(5));
					pro.setPrice(res.getDouble(6));
					pro.setImg(res.getString(7));
					pro.setIntorduc(res.getString(8));
					list.add(pro);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(res, pre, conn);
			}
			return list;
		}

		// �����Ʒ��������
		@Override
		public int getProCount() {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			int count = 0;
			String sql = "select count(*) from product";
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				re = pre.executeQuery();
				if (re.next()) {
					count = re.getInt(1);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(re, pre, conn);
			}

			return count;
		}

		// ͨ��id��ʾһ����Ʒ��Ϣ
		@Override
		public Product getApro(int id) {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet res = null;
			Product pro = null;
			String sql = "select * from product where id=?";
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setInt(1, id);
				res = pre.executeQuery();
				if (res.next()) {
					pro = new Product();
					pro.setId(res.getInt(1));
					pro.setProid(res.getString(2));
					pro.setName(res.getString(3));
					pro.setShangbiao(res.getString(4));
					pro.setTypees(res.getString(5));
					pro.setPrice(res.getDouble(6));
					pro.setImg(res.getString(7));
					pro.setIntorduc(res.getString(8));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(res, pre, conn);
			}
			return pro;
		}

		// ����һ���û�
		@Override
		public int addUser(Users us) {
			Connection conn = null;
			PreparedStatement pre = null;
			String sql = "insert into users values(lwj_use.nextval,?,?,?)";
			int i = 0;
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setString(1, us.getName());
				pre.setString(2, us.getPassword());
				pre.setInt(3, us.getAdmin());
				i = pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		// ��������û���Ϣ
		@Override
		public List<Users> listUse() {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet res = null;
			List<Users> list = new ArrayList<>();
			String sql = "select * from users";
			Users us = null;
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				res = pre.executeQuery();
				while (res.next()) {
					us = new Users();
					us.setId(res.getInt(1));
					us.setName(res.getString(2));
					us.setPassword(res.getString(3));
					us.setAdmin(res.getInt(4));
					list.add(us);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(res, pre, conn);
			}

			return list;
		}

		// ͨ��idɾ��һ���û�
		@Override
		public int delUser(int id) {
			Connection conn = null;
			PreparedStatement pre = null;
			String sql = "delete users where id=?";
			int i = 0;
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setInt(1, id);
				i = pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		// ͨ��id�޸�һ���û���Ϣ
		@Override
		public int dateUser(Users us) {
			Connection conn = null;
			PreparedStatement pre = null;
			int i = 0;
			String sql = "update users set name=?,password=?,admin=? where id=?";
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setString(1, us.getName());
				pre.setString(2, us.getPassword());
				pre.setInt(3, us.getAdmin());
				pre.setInt(4, us.getId());
				i = pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		// ͨ��id��ʾһ���û���Ϣ
		@Override
		public Users getUser(int id) {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			Users us = null;
			String sql = "select * from users where id=?";
			try {
				conn = DBHelper.getconn();
				pre = conn.prepareStatement(sql);
				pre.setInt(1, id);
				re = pre.executeQuery();
				if (re.next()) {
					us = new Users();
					us.setId(re.getInt(1));
					us.setName(re.getString(2));
					us.setPassword(re.getString(3));
					us.setAdmin(re.getInt(4));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBHelper.closeAll(re, pre, conn);
			}
			return us;
		}

		
		//����һ������
		@Override
		public int addNews(News news) {
			Connection conn = null;
			PreparedStatement pre = null;
			int i = 0;
			String sql = "insert into news values(lwj_news.nextval,?,?,?)";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setString(1, news.getNewtitle());
				pre.setString(2, news.getNewconter());
				pre.setString(3, news.getNewtime());
				i=pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		// ����һ����Ʒ
		@Override
		public int addPro(Product pro) {
			Connection conn = null;
			PreparedStatement pre = null;
			int i =0;
			String sql = "insert into product values(lwj_pro.nextval,?,?,?,?,?,?,?)";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setString(1, pro.getProid());
				pre.setString(2, pro.getName());
				pre.setString(3, pro.getShangbiao());
				pre.setString(4, pro.getTypees());
				pre.setDouble(5, pro.getPrice());
				pre.setString(6, pro.getImg());
				pre.setString(7, pro.getIntorduc());
				i=pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		
		//��ʾ��������
		@Override
		public List<News> listNew() {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet res = null;
			String sql = "select * from news";
			News ne = new News();
			List<News> list = new ArrayList<News>();
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				res=pre.executeQuery();
				while(res.next()){
					ne = new News();
					ne.setId(res.getInt(1));
					ne.setNewtitle(res.getString(2));
					ne.setNewconter(res.getString(3));
					ne.setNewtime(res.getString(4));
					list.add(ne);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(res, pre, conn);
			}
			return list;
		}

		//��ʾ���е���Ʒ
		@Override
		public List<Product> listPro() {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet re = null;
			List<Product> list = new ArrayList<Product>();
			Product pro = null;
			String sql = "select * from product";
			try {
				conn = DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				re=pre.executeQuery();
				while(re.next()){
					pro = new Product();
					pro.setId(re.getInt(1));
					pro.setProid(re.getString(2));
					pro.setName(re.getString(3));
					pro.setShangbiao(re.getString(4));
					pro.setTypees(re.getString(5));
					pro.setPrice(re.getDouble(6));
					pro.setImg(re.getString(7));
					pro.setIntorduc(re.getString(8));
					list.add(pro);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(re, pre, conn);
			}
			
			return list;
		}

		//ͨ��id�޸�����
		@Override
		public int dateNews(News news) {
			Connection conn = null;
			PreparedStatement pre =null;
			int i = 0;
			String sql = "update news set newtitle=?,newconter=?,newtime=? where id=?";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setString(1, news.getNewtitle());
				pre.setString(2, news.getNewconter());
				pre.setString(3, news.getNewtime());
				pre.setInt(4, news.getId());
				i=pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		//ͨ��idɾ������
		@Override
		public int deleNews(int id) {
			Connection conn = null;
			PreparedStatement pre = null;
			int i=0;
			String sql = "delete news where id=?";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setInt(1, id);
				i=pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}
		
		// ͨ��id�޸�һ����Ʒ
		@Override
		public int datePro(Product pro) {
			Connection conn = null;
			PreparedStatement pre = null;
			int i = 0;
			String sql = "update product set proid=?,name=?,shangbiao=?,typees=?,price=?,img=?,intorduc=? where id=? ";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setString(1, pro.getProid());
				pre.setString(2, pro.getName());
				pre.setString(3, pro.getShangbiao());
				pre.setString(4, pro.getTypees());
				pre.setDouble(5, pro.getPrice());
				pre.setString(6, pro.getImg());
				pre.setString(7, pro.getIntorduc());
				pre.setInt(8, pro.getId());
				i=pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				DBHelper.closeAll(null, pre, conn);
			}
			return i;
		}

		// ͨ��idɾ��һ����Ʒ
		@Override
		public int delePro(int id) {
			Connection conn = null;
			PreparedStatement pre = null;
			int i = 0;
			String sql = "delete product where id=?";
			try {
				conn=DBHelper.getconn();
				pre=conn.prepareStatement(sql);
				pre.setInt(1, id);
				i=pre.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return i;
		}
	}