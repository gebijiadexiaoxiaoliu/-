package com.rw.mvc.impl;

import java.util.List;
import com.rw.mvc.dao.CompanyDao;
import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.FenYe;
import com.rw.mvc.entity.News;
import com.rw.mvc.entity.Product;
import com.rw.mvc.entity.Users;

public class CompanyServiceImpl implements CompanyServiceDao{

	CompanyDao dao = new CompanyImpl();
	
	// �û���½
	@Override
	public Users login(String name, String password) {
		return dao.login(name, password);
	}
	
	// �������������
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return dao.getCount();
	}
	
	// ������ŷ�ҳ
	@Override
	public List<News> tabAll(FenYe fy) {
		// TODO Auto-generated method stub
		return dao.tabAll(fy);
	}
	
	//ͨ��id��ʾһ������
	@Override
	public News getAnews(int id) {
		// TODO Auto-generated method stub
		return dao.getAnews(id);
	}
	
	//��Ʒ��ҳ
	@Override
	public List<Product> tabPro(FenYe fy) {
		// TODO Auto-generated method stub
		return dao.tabPro(fy);
	}
	
	//�����Ʒ������
	@Override
	public int getProCount() {
		// TODO Auto-generated method stub
		return dao.getProCount();
	}
	
	//ͨ��id��ʾһ����Ʒ��Ϣ
	@Override
	public Product getApro(int id) {
		// TODO Auto-generated method stub
		return dao.getApro(id);
	}

	//����һ���û�
	@Override
	public int addUser(Users us) {
		// TODO Auto-generated method stub
		return dao.addUser(us);
	}

	//��������û���Ϣ
	@Override
	public List<Users> listUse() {
		// TODO Auto-generated method stub
		return dao.listUse();
	}

	// ͨ��idɾ��һ���û�
	@Override
	public int delUser(int id) {
		// TODO Auto-generated method stub
		return dao.delUser(id);
	}

	// ͨ��id�޸�һ���û���Ϣ
	@Override
	public int dateUser(Users us) {
		// TODO Auto-generated method stub
		return dao.dateUser(us);
	}

	//ͨ��id��ʾ�û���Ϣ
	@Override
	public Users getUser(int id) {
		
		return dao.getUser(id);
	}

	//����һ������
	@Override
	public int addNews(News news) {
		// TODO Auto-generated method stub
		return dao.addNews(news);
	}

	// ����һ����Ʒ
	@Override
	public int addPro(Product pro) {
		// TODO Auto-generated method stub
		return dao.addPro(pro);
	}

	//��ʾ���е�����
	@Override
	public List<News> listNew() {
		// TODO Auto-generated method stub
		return dao.listNew();
	}

	//��ʾ���е���Ʒ
	@Override
	public List<Product> listPro() {
		// TODO Auto-generated method stub
		return dao.listPro();
	}

	@Override
	public int dateNews(News news) {
		// TODO Auto-generated method stub
		return dao.dateNews(news);
	}

	@Override
	public int deleNews(int id) {
		// TODO Auto-generated method stub
		return dao.deleNews(id);
	}

	@Override
	public int datePro(Product pro) {
		// TODO Auto-generated method stub
		return dao.datePro(pro);
	}

	@Override
	public int delePro(int id) {
		// TODO Auto-generated method stub
		return dao.delePro(id);
	}

}
