package com.rw.mvc.impl;

import java.util.List;

import com.rw.mvc.dao.MessageDao;
import com.rw.mvc.dao.MessageServicdao;
import com.rw.mvc.entity.Message;

public class MessageServicdaoImp implements MessageServicdao{
	MessageDao dao = new MessageDaoImp(); 
	@Override
	public List<Message> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public int addUsersDao(Message message) {
		// TODO Auto-generated method stub
		return dao.addUsersDao(message);
	}

	@Override
	public Message getMessageByname(String receiveUname) {
		// TODO Auto-generated method stub
		return dao.getMessageByname(receiveUname);
	}

	@Override
	public Message getMessageBysendUname(String sendUname) {
		// TODO Auto-generated method stub
		return dao.getMessageBysendUname(sendUname);
	}

	@Override
	public int upperMessage(int re,int id) {
		// TODO Auto-generated method stub
		return dao.upperMessage(re,id);
	}

	@Override
	public Message getmessageByid(int id) {
		// TODO Auto-generated method stub
		return dao.getmessageByid(id);
	}

	@Override
	public List<Message> showRadioAll(int id) {
		// TODO Auto-generated method stub
		return dao.showRadioAll(id);
	}

}
