package com.rw.mvc.impl;

import com.rw.mvc.dao.UserxDao;
import com.rw.mvc.dao.UserxServiceDao;
import com.rw.mvc.entity.Userx;

public class UserxServiceDaoImp implements UserxServiceDao {
	UserxDao dao = new UserxDaoImp();
	@Override
	public Userx login(String name, String password) {
		// TODO Auto-generated method stub
		return dao.login(name, password);
	}

}
