package com.rw.mvc.impl;

import java.util.List;

import com.rw.mvc.dao.MainsDao;
import com.rw.mvc.dao.MainsServiceDao;
import com.rw.mvc.entity.Mains;

public class MainsServiceDaoImp implements MainsServiceDao {
	MainsDao dao = new MainsDaoImp();
	@Override
	public List<Mains> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public int addUsersDao(Mains mains) {
		// TODO Auto-generated method stub
		return dao.addUsersDao(mains);
	}

	@Override
	public Mains getMessageByname(String receiveUname) {
		// TODO Auto-generated method stub
		return dao.getMessageByname(receiveUname);
	}

	@Override
	public Mains getMessageBysendUname(String sendUname) {
		// TODO Auto-generated method stub
		return dao.getMessageBysendUname(sendUname);
	}

	@Override
	public int upperMessage(int re, int id) {
		// TODO Auto-generated method stub
		return dao.upperMessage(re, id);
	}

	@Override
	public Mains getMainsgeByid(int id) {
		// TODO Auto-generated method stub
		return dao.getMainsgeByid(id);
	} 
	
}
