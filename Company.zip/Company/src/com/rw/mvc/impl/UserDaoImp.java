package com.rw.mvc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.spi.DirStateFactory.Result;

import com.rw.mvc.dao.UserDao;
import com.rw.mvc.entity.DBHelper;
import com.rw.mvc.entity.User;

public class UserDaoImp implements UserDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	User user = null;
	@Override
	public User login(String name, String password) {
		String sql = "select * from user1 where name=? and password=?";
		
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			if(rs.next()){
				user = new User();
				user.setId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setPassword(rs.getString(3));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		return user;
	}


}
