package com.rw.mvc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.rw.mvc.dao.MessageDao;
import com.rw.mvc.entity.DBHelper;
import com.rw.mvc.entity.Message;

public class MessageDaoImp implements MessageDao {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Message message = null;
	
	@Override
	public List<Message> showAll() {
		String sql = "select * from message";
		List<Message> list = new ArrayList<Message>();
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				message = new Message();
				message.setId(rs.getInt(1));
				message.setNote(rs.getString(2));
				message.setTitle(rs.getString(3));
				message.setSendUname(rs.getString(4));
				message.setReceiveUname(rs.getString(5));
				message.setHuifu(rs.getString(6));
				message.setPostTime(rs.getString(7));
				message.setReadSign(rs.getInt(8));
				list.add(message);
			}	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public int addUsersDao(Message message) {
		int i =0;
		String sql = "insert into message values(seq_message.nextval,?,?,?,?,?,?,0)";
				
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, message.getNote());
			pstmt.setString(2, message.getTitle());
			pstmt.setString(3, message.getSendUname());
			pstmt.setString(4, message.getReceiveUname());
			pstmt.setString(5, message.getHuifu());
			pstmt.setString(6, message.getPostTime());
			i=pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		return i;
	
	}

	@Override
	public Message getMessageByname(String receiveUname) {
		String sql = "select * from message where receiveUname=?";
	try {
		conn=DBHelper.getconn();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, receiveUname);
		rs=pstmt.executeQuery();
		if(rs.next()){
			message = new Message();
			message.setId(rs.getInt(1));
			message.setNote(rs.getString(2));
			message.setTitle(rs.getString(3));
			message.setSendUname(rs.getString(4));
			message.setReceiveUname(rs.getString(5));
			message.setHuifu(rs.getString(6));
			message.setPostTime(rs.getString(7));
			message.setReadSign(rs.getInt(8));
		}
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		DBHelper.closeAll(rs, pstmt, conn);
	}
	return message;
	}

	@Override
	public Message getMessageBysendUname(String sendUname) {
		String sql="select * from message where sendUname=?";
		try {
			conn=DBHelper.getconn();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sendUname);
			rs=pstmt.executeQuery();
			if(rs.next()){
				message = new Message();
				message.setId(rs.getInt(1));
				message.setNote(rs.getString(2));
				message.setTitle(rs.getString(3));
				message.setSendUname(rs.getString(4));
				message.setReceiveUname(rs.getString(5));
				message.setHuifu(rs.getString(6));
				message.setPostTime(rs.getString(7));
				message.setReadSign(rs.getInt(8));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		return message;
	}

	@Override
	public int upperMessage(int re,int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "update message set readSign=? where id=?";
		int i = 0;
		Message me = new Message();
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, re);
			pstmt.setInt(2, id);
			i=pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		return i;
	}

	@Override
	public Message getmessageByid(int id) {
		String sql="select * from message where id=?";
		try {
			conn=DBHelper.getconn();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()){
				message = new Message();
				message.setId(rs.getInt(1));
				message.setNote(rs.getString(2));
				message.setTitle(rs.getString(3));
				message.setSendUname(rs.getString(4));
				message.setReceiveUname(rs.getString(5));
				message.setHuifu(rs.getString(6));
				message.setPostTime(rs.getString(7));
				message.setReadSign(rs.getInt(8));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		return message;
	}

	@Override
	public List<Message> showRadioAll(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql ="select m.readSign,m.sendUname,m.note from message m where id=?";
		List<Message> list = new ArrayList<Message>();
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				message = new Message();
				message.setReadSign(rs.getInt(1));
				message.setSendUname(rs.getString(2));
				message.setNote(rs.getString(3));
				list.add(message);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		
		return list;
	}

}
