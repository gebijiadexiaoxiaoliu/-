package com.rw.mvc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.rw.mvc.dao.UsebDao;
import com.rw.mvc.entity.DBHelper;
import com.rw.mvc.entity.Useb;

public class UsebImp implements UsebDao{
			// �������
			Connection conn = null;
			// Ԥ�������
			PreparedStatement pstmt = null;
			// ������
			ResultSet rs = null;
			
	@Override
	public List<Useb> showAll() {
		String sql ="select * from useb";
		List<Useb> list = new ArrayList<Useb>();
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Useb useb = new Useb();
				useb.setId(rs.getInt(1));
				useb.setName(rs.getString(2));
				list.add(useb);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public int addUsebDao(Useb useb) {
		String sql = "insert into useb values(seq_useb.nextval,?)";
		int i = 0;
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, useb.getName());
			
			i= pstmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		return i;
	}

	@Override
	public int delete(String name) {
		String sql = "delete useb where name=?";
		int i = 0;
		
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, name);
			
			i = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		return i;
	}

}
