package com.rw.mvc.impl;

import com.rw.mvc.dao.UserDao;
import com.rw.mvc.dao.UserServicdao;
import com.rw.mvc.entity.User;

public class UserServicdaoimp implements UserServicdao {
	UserDao dao = new UserDaoImp();
	@Override
	public User login(String name, String password) {
		// TODO Auto-generated method stub
		return dao.login(name, password);
	}

}
