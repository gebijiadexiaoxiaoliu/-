package com.rw.mvc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.rw.mvc.dao.MainsDao;
import com.rw.mvc.entity.DBHelper;
import com.rw.mvc.entity.Mains;

public class MainsDaoImp implements MainsDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Mains mains = null;
	@Override
	public List<Mains> showAll() {
		String sql = "select * from mains";
		List<Mains> list = new ArrayList<Mains>();
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				mains = new Mains();
				mains.setId(rs.getInt(1));
				mains.setNote(rs.getString(2));
				mains.setSendUname(rs.getString(3));
				mains.setReceiveUname(rs.getString(4));
				mains.setPostTime(rs.getString(5));
				list.add(mains);
			}	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public int addUsersDao(Mains mains) {
		String sql = "insert into mains values(seq_mains.nextval,?,?,?,?)";
		int i = 0;
		try {
			conn = DBHelper.getconn();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, mains.getNote());
			pstmt.setString(2, mains.getSendUname());
			pstmt.setString(3, mains.getReceiveUname());
			pstmt.setString(4, mains.getPostTime());
			
			i= pstmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBHelper.closeAll(rs, pstmt, conn);
		}
		
		return i;
	}

	@Override
	public Mains getMessageByname(String receiveUname) {
		String sql = "select * from mains where receiveUname=?";
	try {
		conn=DBHelper.getconn();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, receiveUname);
		rs=pstmt.executeQuery();
		if(rs.next()){
			mains = new Mains();
			mains.setId(rs.getInt(1));
			mains.setNote(rs.getString(2));
			mains.setSendUname(rs.getString(3));
			mains.setReceiveUname(rs.getString(4));
			mains.setPostTime(rs.getString(5));
		}
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		DBHelper.closeAll(rs, pstmt, conn);
	}
	return mains;
	}

	@Override
	public Mains getMessageBysendUname(String sendUname) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int upperMessage(int re, int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Mains getMainsgeByid(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
