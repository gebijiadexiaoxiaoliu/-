package com.rw.mvc.dao;


import com.rw.mvc.entity.Userx;

public interface UserxServiceDao {	

	//��¼�ķ���
	 Userx login(String name,String password);

	}
