package com.rw.mvc.dao;

import com.rw.mvc.entity.Userx;


public interface UserxDao {
	//��¼�ķ���
	 Userx login(String name,String password);
}
