package com.rw.mvc.dao;

import com.rw.mvc.entity.User;

public interface UserServicdao {
	//��¼�ķ���
	 User login(String name,String password);
}
