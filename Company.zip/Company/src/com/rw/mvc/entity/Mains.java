package com.rw.mvc.entity;

public class Mains {
	private int id; 
	private String note; 
	private String sendUname;
	private String receiveUname;
	private String postTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getSendUname() {
		return sendUname;
	}
	public void setSendUname(String sendUname) {
		this.sendUname = sendUname;
	}
	public String getReceiveUname() {
		return receiveUname;
	}
	public void setReceiveUname(String receiveUname) {
		this.receiveUname = receiveUname;
	}
	public String getPostTime() {
		return postTime;
	}
	public void setPostTime(String postTime) {
		this.postTime = postTime;
	}
	public Mains() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mains(int id, String note, String sendUname, String receiveUname,
			String postTime) {
		super();
		this.id = id;
		this.note = note;
		this.sendUname = sendUname;
		this.receiveUname = receiveUname;
		this.postTime = postTime;
	}
	
	
}
