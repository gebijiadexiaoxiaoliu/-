package com.rw.mvc.entity;

public class Users {

	private int id;//id
	private String name;//����
	private String password;//����
	private int admin;//����Ա��ǹ���Ա
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAdmin() {
		return admin;
	}
	public void setAdmin(int admin) {
		this.admin = admin;
	}
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(int id, String name, String password, int admin) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.admin = admin;
	}
	
	
}
