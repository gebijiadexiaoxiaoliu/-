package com.rw.mvc.entity;

public class LiuYan {
	private int id;
	private String name;
	private String zuozhe;
	private String title;
	private String content;
	private String posttime;
	private int huifu;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getZuozhe() {
		return zuozhe;
	}
	public void setZuozhe(String zuozhe) {
		this.zuozhe = zuozhe;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPosttime() {
		return posttime;
	}
	public void setPosttime(String posttime) {
		this.posttime = posttime;
	}
	public int getHuifu() {
		return huifu;
	}
	public void setHuifu(int huifu) {
		this.huifu = huifu;
	}
	public LiuYan(int id, String name, String zuozhe, String title, String content, String posttime, int huifu) {
		super();
		this.id = id;
		this.name = name;
		this.zuozhe = zuozhe;
		this.title = title;
		this.content = content;
		this.posttime = posttime;
		this.huifu = huifu;
	}
	public LiuYan() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
