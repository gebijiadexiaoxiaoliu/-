package com.rw.mvc.entity;

public class News {
	private int id;
	private String newtitle;
	private String newconter;
	private String newtime;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNewtitle() {
		return newtitle;
	}
	public void setNewtitle(String newtitle) {
		this.newtitle = newtitle;
	}
	public String getNewconter() {
		return newconter;
	}
	public void setNewconter(String newconter) {
		this.newconter = newconter;
	}
	public String getNewtime() {
		return newtime;
	}
	public void setNewtime(String newtime) {
		this.newtime = newtime;
	}
	public News(int id, String newtitle, String newconter, String newtime) {
		super();
		this.id = id;
		this.newtitle = newtitle;
		this.newconter = newconter;
		this.newtime = newtime;
	}
	public News() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
