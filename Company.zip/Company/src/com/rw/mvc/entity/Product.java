package com.rw.mvc.entity;

public class Product {
	private int id;
	private String proid;
	private String name;
	private String shangbiao;
	private String typees;
	private double price;
	private String img;
	private String intorduc;
	
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int id, String proid, String name, String shangbiao, String typees, double price, String img,
			String intorduc) {
		super();
		this.id = id;
		this.proid = proid;
		this.name = name;
		this.shangbiao = shangbiao;
		this.typees = typees;
		this.price = price;
		this.img = img;
		this.intorduc = intorduc;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProid() {
		return proid;
	}
	public void setProid(String proid) {
		this.proid = proid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShangbiao() {
		return shangbiao;
	}
	public void setShangbiao(String shangbiao) {
		this.shangbiao = shangbiao;
	}
	public String getTypees() {
		return typees;
	}
	public void setTypees(String typees) {
		this.typees = typees;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getIntorduc() {
		return intorduc;
	}
	public void setIntorduc(String intorduc) {
		this.intorduc = intorduc;
	}

	
}
