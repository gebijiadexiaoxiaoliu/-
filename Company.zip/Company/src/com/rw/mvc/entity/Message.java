package com.rw.mvc.entity;

public class Message {
	

	private int id; 
	private String note; 
	private String title; 
	private String sendUname;
	private String receiveUname;
	private String huifu;
	private String postTime;
	private int readSign;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSendUname() {
		return sendUname;
	}
	public void setSendUname(String sendUname) {
		this.sendUname = sendUname;
	}
	public String getReceiveUname() {
		return receiveUname;
	}
	public void setReceiveUname(String receiveUname) {
		this.receiveUname = receiveUname;
	}
	public String getHuifu() {
		return huifu;
	}
	public void setHuifu(String huifu) {
		this.huifu = huifu;
	}
	public String getPostTime() {
		return postTime;
	}
	public void setPostTime(String postTime) {
		this.postTime = postTime;
	}
	public int getReadSign() {
		return readSign;
	}
	public void setReadSign(int readSign) {
		this.readSign = readSign;
	}
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Message(int id, String note, String title, String sendUname,
			String receiveUname, String huifu, String postTime) {
		super();
		this.id = id;
		this.note = note;
		this.title = title;
		this.sendUname = sendUname;
		this.receiveUname = receiveUname;
		this.huifu = huifu;
		this.postTime = postTime;
	}

	
}
