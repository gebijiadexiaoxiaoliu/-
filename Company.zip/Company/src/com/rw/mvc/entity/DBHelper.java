package com.rw.mvc.entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBHelper {
	private static final String NAME="system";
	private static final String PASSWORD="xiaoliu";
	private static final String URL="jdbc:oracle:thin:@172.16.0.108:1521:system";
	private static final String CLASS_NAME="oracle.jdbc.driver.OracleDriver";
	
	public static Connection getconn() throws Exception {
		Class.forName(CLASS_NAME);
		return DriverManager.getConnection(URL, NAME, PASSWORD);
		
	}
	
	public static void closeAll(ResultSet rs,PreparedStatement pre,Connection conn){
		try {
			if(rs!=null){
				rs.close();
			}
			if(pre!=null){
				pre.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
