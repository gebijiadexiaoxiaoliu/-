package com.rw.mvc.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.News;
import com.rw.mvc.impl.CompanyServiceImpl;

public class AddNewServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		String newtitle = request.getParameter("newtitle");
		String newconter = request.getParameter("newconter");
		SimpleDateFormat date = new SimpleDateFormat("yyyy-mm-dd");
		Date da = new Date();
		String time = date.format(da);
		
		News ne = new News(1, newtitle, newconter, time);
		
		CompanyServiceDao dao = new CompanyServiceImpl();
		int n = dao.addNews(ne);
		
		if(n>0){
			request.getRequestDispatcher("AdminNewsServlet").forward(request, response);
		}else{
			request.setAttribute("lwj", "��������ʧ��");
			request.getRequestDispatcher("admin/addNew.jsp").forward(request, response);
		}
	}
}
