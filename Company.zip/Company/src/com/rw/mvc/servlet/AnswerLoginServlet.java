package com.rw.mvc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rw.mvc.dao.MessageServicdao;
import com.rw.mvc.dao.UserServicdao;
import com.rw.mvc.entity.Message;
import com.rw.mvc.entity.User;
import com.rw.mvc.impl.MessageServicdaoImp;
import com.rw.mvc.impl.UserServicdaoimp;

public class AnswerLoginServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		MessageServicdao da=new MessageServicdaoImp();
		//22
		UserServicdao dao = new UserServicdaoimp();
		User taba=dao.login("�����", "123456");
		if (taba!=null){
			List<Message> list=da.showAll();
			HttpSession session=request.getSession();
			session.setAttribute("tab",taba);
			request.setAttribute("list", list);
			request.getRequestDispatcher("message.jsp").forward(request,response);
		} else {
			request.getRequestDispatcher("index.jsp").forward(request,response);
		}
	}
}