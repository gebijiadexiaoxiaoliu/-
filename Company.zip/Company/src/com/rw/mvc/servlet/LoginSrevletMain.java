package com.rw.mvc.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.MainsServiceDao;
import com.rw.mvc.entity.Mains;
import com.rw.mvc.impl.MainsServiceDaoImp;

public class LoginSrevletMain extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		MainsServiceDao dao = new MainsServiceDaoImp();
			List<Mains> list =dao.showAll();
			request.getSession().setAttribute("list", list);
			
			request.getRequestDispatcher("message1.jsp")
					.forward(request, response);
		
	}

}
