package com.rw.mvc.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.MessageServicdao;
import com.rw.mvc.entity.Message;
import com.rw.mvc.impl.MessageServicdaoImp;

public class AnswerSrevlet2 extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			request.setCharacterEncoding("utf-8");
			SimpleDateFormat da = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			String time = da.format(date);
			String note = request.getParameter("note");
			String name = request.getParameter("name");
			String huifu = request.getParameter("huifu");
			String title = request.getParameter("title");
			MessageServicdao dao=new MessageServicdaoImp();
			Message message = new Message(0,note,title,"�����",name,huifu,time);
			int i = dao.addUsersDao(message);
			if (i>0){
				List<Message> list= dao.showAll();
				request.setAttribute("list", list);
				request.getRequestDispatcher("message.jsp").forward(request,response);
			} else {
				request.getRequestDispatcher("index.jsp").forward(request,response);
		}
	}
}
