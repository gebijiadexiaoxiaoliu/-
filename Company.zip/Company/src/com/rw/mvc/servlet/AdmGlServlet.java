package com.rw.mvc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.Users;
import com.rw.mvc.impl.CompanyServiceImpl;

public class AdmGlServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		CompanyServiceDao dao = new CompanyServiceImpl();
		List<Users> list = dao.listUse();
		request.setAttribute("list",list);
		request.getRequestDispatcher("admin/admGL.jsp").forward(request, response);
	}
}
