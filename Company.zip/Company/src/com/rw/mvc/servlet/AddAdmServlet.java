package com.rw.mvc.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.Users;
import com.rw.mvc.impl.CompanyServiceImpl;

public class AddAdmServlet extends HttpServlet {
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		int user = Integer.parseInt(request.getParameter("user"));
		
		CompanyServiceDao dao = new CompanyServiceImpl();
		Users us = new Users(1, name, password, user);
		dao.addUser(us);
		request.getRequestDispatcher("AdmGlServlet").forward(request, response);
	}
}
