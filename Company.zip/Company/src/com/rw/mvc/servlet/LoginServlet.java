package com.rw.mvc.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.Users;
import com.rw.mvc.impl.CompanyServiceImpl;

public class LoginServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("hao");
		String password = request.getParameter("password");
		
		CompanyServiceDao dao = new CompanyServiceImpl();
		Users user = dao.login(name, password);
		if(user==null){
			request.setAttribute("lwj", "������˺�|��������");
			request.getRequestDispatcher("admin/admhoutai.jsp").forward(request, response);
		}
		
		int admin = user.getAdmin();
		
		if(admin==1){
			HttpSession session=request.getSession();
			session.setAttribute("user", user);
			request.getRequestDispatcher("admin/admindex.jsp").forward(request, response);
		}else if(admin==0){
			request.setAttribute("lwj", "�����ǳ�������Ա���޷���¼��");
			request.getRequestDispatcher("admin/admhoutai.jsp").forward(request, response);
		}else{
			request.setAttribute("lwj", "������˺�|��������");
			request.getRequestDispatcher("admin/admhoutai.jsp").forward(request, response);
		}
		
	}
}
