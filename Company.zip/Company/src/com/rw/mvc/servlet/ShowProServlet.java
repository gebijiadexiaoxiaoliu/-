package com.rw.mvc.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.Product;
import com.rw.mvc.impl.CompanyServiceImpl;

public class ShowProServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		int id = Integer.parseInt(request.getParameter("id"));
		
		CompanyServiceDao dao = new CompanyServiceImpl();
		Product pro = dao.getApro(id);
		request.setAttribute("pro",pro);
		request.getRequestDispatcher("showShangPin.jsp").forward(request, response);
	}
}
