package com.rw.mvc.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class OutServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
			HttpSession session = request.getSession();	
			request.setCharacterEncoding("utf-8");
		 	
		    session.removeAttribute("user");
		    session.invalidate();
		    request.getRequestDispatcher("admin/admhoutai.jsp?").forward(request, response);
		    
		   /* String userName = (String) session.getAttribute("User");
			if (null == userName) {  
			   request.setAttribute("Error", "Session has ended.  Please login.");  
			   request.getRequestDispatcher("login.jsp").forward(request, response);;  
			}*/
	}
}
