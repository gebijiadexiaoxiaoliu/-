package com.rw.mvc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.FenYe;
import com.rw.mvc.entity.News;
import com.rw.mvc.impl.CompanyServiceImpl;

public class FenYeServlet extends HttpServlet {
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		int currentPage = Integer.parseInt(request.getParameter("currentPage"));
		int flag = Integer.parseInt(request.getParameter("flag"));
		
		CompanyServiceDao dao = new CompanyServiceImpl();
		FenYe fen = new FenYe();
		fen.setTotalCount(dao.getCount());
		
		if(flag==1){ 
			currentPage=currentPage-1;
		}else if(flag==2){
			currentPage=currentPage+1;
		}else{
			currentPage=fen.getTotalPages();
		}
		
		fen.setCurrentPage(currentPage);
		List<News> list = dao.tabAll(fen);
		request.setAttribute("list",list);
		request.setAttribute("currentPage",fen.getCurrentPage());
		request.getRequestDispatcher("xinWen.jsp").forward(request, response);
	}
}
