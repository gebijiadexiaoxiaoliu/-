package com.rw.mvc.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rw.mvc.dao.MainsServiceDao;
import com.rw.mvc.entity.Mains;
import com.rw.mvc.impl.MainsServiceDaoImp;

public class ZaiXianServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		SimpleDateFormat da1 = new SimpleDateFormat("hh-mm-ss");
		Date date = new Date();
		String time = da1.format(date);
		String name = request.getParameter("name");
		String name1 = request.getParameter("name1");
		String note = request.getParameter("note");
		MainsServiceDao dao = new MainsServiceDaoImp();
		Mains mains = new Mains(0, note, name, name1, time);
		if (note != null) {
			int i = dao.addUsersDao(mains);
			if (i > 0) {
				List<Mains> list = dao.showAll();
				HttpSession session = request.getSession();
				session.setAttribute("list", list);
				request.getRequestDispatcher("message1.jsp").forward(request, response);
			}
		}
	}

}
