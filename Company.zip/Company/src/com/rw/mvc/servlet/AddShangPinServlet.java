package com.rw.mvc.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.CompanyServiceDao;
import com.rw.mvc.entity.Product;
import com.rw.mvc.impl.CompanyServiceImpl;

public class AddShangPinServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String proid = request.getParameter("proid");
		String name = request.getParameter("name");
		String shangbiao = request.getParameter("shangbiao");
		String typees = request.getParameter("typees");
		double price = Double.parseDouble(request.getParameter("price"));
		String img = request.getParameter("img");
		String intorduc = request.getParameter("intorduc");
		Product pro = new Product(1,proid,name,shangbiao,typees,price,img,intorduc);
		
		CompanyServiceDao dao = new CompanyServiceImpl();
		dao.addPro(pro);
		request.getRequestDispatcher("AdminShangPinServlet").forward(request, response);
	}
}
