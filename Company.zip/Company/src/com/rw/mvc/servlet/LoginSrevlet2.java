package com.rw.mvc.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rw.mvc.dao.MainsServiceDao;
import com.rw.mvc.dao.UserxServiceDao;
import com.rw.mvc.entity.Mains;
import com.rw.mvc.entity.Userx;
import com.rw.mvc.impl.MainsServiceDaoImp;
import com.rw.mvc.impl.UserxServiceDaoImp;

public class LoginSrevlet2 extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ��������������ַ�����
		request.setCharacterEncoding("utf-8");

		HttpSession session = request.getSession();
		String name = request.getParameter("name");
		String ps = request.getParameter("ps");
		UserxServiceDao da = new UserxServiceDaoImp();
		MainsServiceDao dao = new MainsServiceDaoImp();
		Userx taba = da.login(name, ps);
		Mains mains = new Mains();
		if (taba != null) {
			Mains list = dao.getMessageByname(taba.getName());
			session.setAttribute("tab", taba);
			session.setAttribute("name1", mains.getReceiveUname());
			session.setAttribute("list", list);
			request.getRequestDispatcher("main.jsp").forward(request, response);
		} else {
			request.getRequestDispatcher("login.jsp").forward(request, response);
			request.setAttribute("sb", "û������û�");
		}
	}
}
