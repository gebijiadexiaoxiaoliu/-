package com.rw.mvc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rw.mvc.dao.MainsServiceDao;
import com.rw.mvc.dao.UsebDao;
import com.rw.mvc.entity.Mains;
import com.rw.mvc.entity.Useb;
import com.rw.mvc.impl.MainsServiceDaoImp;
import com.rw.mvc.impl.UsebImp;

public class showUserListServlet extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				//��������������ַ�����
				request.setCharacterEncoding("utf-8");
				String name = request.getParameter("name");
				UsebDao dao = new UsebImp();
				Useb useb = new Useb(0,name);
				
				
				boolean falg = true;
					List<Useb> list1 = dao.showAll();
					for (int j = 0; j < list1.size(); j++) {
						if(name.equals(list1.get(j).getName())){	
							request.getRequestDispatcher("aaaa.jsp").forward(request,response);
							falg=false;
						}
					}
					if(falg){
					int i = dao.addUsebDao(useb);
					if(i>0){
					request.setAttribute("s", useb);
					request.getSession().setAttribute("list1", list1);
					request.getRequestDispatcher("showUserList.jsp").forward(request,response);
					}
					}
	}
}
