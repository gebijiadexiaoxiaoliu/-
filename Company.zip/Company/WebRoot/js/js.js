
function checkName(){
		var name = document.getElementById("name").value;
		if(name==null || name==""){
		nameDiv.innerHTML="<font color='red'>*名字必填</font>";
			return false;
		}else if(!(name == "鲁文杰" || name == "李典易")){
		nameDiv.innerHTML="<font color='red'>数据库没有这个用户</font>";
			return false;
		}else{
			return true;
		}
}

function checkTitle(){
	var title= document.getElementById("title").value;
	if(title==null || title==""){
	titleDiv.innerHTML="<font color='red'>*标题不能为空</font>";
		return false;
	}else{
		return true;
	}
}

function checkNote(){
	var note= document.getElementById("note").value;
	if(note==null || note==""){
	noteDiv.innerHTML="<font color='red'>*内容不能为空</font>";
		return false;
	}else{
		return true;
	}
}

function checkAll(){
	if(checkName()&&checkTitle()&&checkNote()){
		return true;
	}else{
		return false;
	}
	
}

function checkAll1(v) {
	if(v=="留言"){
	document.getElementById("diva").style.display="none";
	document.getElementById("divb").style.display="inline";
	document.getElementById("b").value = "新留言";
	}else{
	document.getElementById("diva").style.display="inline";
	document.getElementById("divb").style.display="none";
	document.getElementById("b").value = "留言";
	}
}