function checkName(){
	var name = document.getElementById("name").value;
	if(name==""||name==null){
		alert("姓名 不能为空!!!");
	}else if(name.length<2){
		alert("姓名长度两位以上");
	}else{
		return true;
	}
	
}

function checkPhone(){
	var phone = document.getElementById("phone").value;
	if(phone==""||phone==null){
		alert("电话不能为空!!!");
	}else if(phone.length<11||phone.length>11){
	}else{
		alert("电话长度必须为11位!!!");
		return true;
	}
	
}

function checkPass(){
	var pass = document.getElementById("password").value;
	if(pass==""||pass==null){
		alert("密码 不能为空!!!");
	}else if(pass.length<6){
		alert("密码 长度大于6位数!!!");
	}else{
		return true;
	}
	
}


function checkAddress(){
	var address = document.getElementById("address").value;
	if(address==""||address==null){
		alert("地址不能为空!!!");
	}else{
		return true;
	}
	
}

function checkAll(){
	if(checkName()&&checkPhone()&&checkPass()&&checkAddress()){
		alert("信息填写成功！！！！，已提交服务器");
		return true;
	}else{
		return false;
	}
	
}
